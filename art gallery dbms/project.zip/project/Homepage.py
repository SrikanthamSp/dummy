import streamlit as st

st.set_page_config(
    page_title="Art Gallery Management System"
)

st.title("Art Gallery Management System")
st.sidebar.success("Select a page above")